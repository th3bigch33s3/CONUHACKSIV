package models.users;

import java.time.LocalDate;

public class Admin {
	private User_id userId;
}
