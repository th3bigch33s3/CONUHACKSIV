package models.enums;

public class ActivityCategory {
}
